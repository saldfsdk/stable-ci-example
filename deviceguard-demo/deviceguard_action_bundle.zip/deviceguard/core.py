from __future__ import annotations
from pathlib import Path
from deviceguard.adapters import ADAPTERS
from deviceguard.adapters import document as document_adapter
from deviceguard.adapters import specdiff as specdiff_adapter
from deviceguard.scanner import scan_repo
from deviceguard.impact import evaluate
from deviceguard.models import Report


def run_check(
    vendor: str,
    product: str,
    from_version: str,
    to_version: str,
    repo: Path,
    *,
    refresh_vendor_data: bool = False,
    vendor_doc: Path | None = None,
    old_spec: Path | None = None,
    new_spec: Path | None = None,
) -> Report:
    document_scope = None
    spec_verification = None
    if (old_spec is None) != (new_spec is None):
        raise ValueError("Use --old-spec and --new-spec together.")
    if vendor_doc is not None:
        changes, document_scope = document_adapter.analyze_document(vendor_doc, from_version, to_version)
    else:
        key = (vendor.lower(), product.lower())
        if key in ADAPTERS:
            adapter = ADAPTERS[key]
            try:
                changes = adapter.changes(from_version, to_version, refresh=refresh_vendor_data)
            except TypeError:
                # Backward-compatible path for prototype adapters that do not yet need refresh.
                changes = adapter.changes(from_version, to_version)
        elif old_spec is not None and new_spec is not None:
            # Spec-only mode supports vendors without a built-in release-note adapter.
            changes = []
        else:
            raise ValueError(f"Unsupported adapter: {vendor}/{product}")

    if old_spec is not None and new_spec is not None:
        spec_changes, spec_verification = specdiff_adapter.diff_specs(old_spec, new_spec)

        # A deterministic manual diff supersedes a weaker release-note REVIEW
        # for the same command. This avoids noisy output such as REVIEW + BLOCK
        # for AT+QPING when the manual proves the exact signature change.
        verified_commands: set[str] = set()
        for change in spec_changes:
            if change.kind in {"command", "parameter"}:
                verified_commands.add(change.symbol)
            elif change.kind == "response":
                response = change.symbol.rstrip(":")
                if response.startswith(("+", "#", "%")):
                    verified_commands.add("AT" + response)
        changes = [
            c for c in changes
            if not (c.change_type == "behavior_changed" and c.symbol in verified_commands)
        ]

        # Keep release-note evidence and deterministic spec evidence side by side.
        # Exact duplicates are collapsed in favor of the higher-confidence spec diff.
        merged: dict[tuple[str, str, str], object] = {}
        for change in [*changes, *spec_changes]:
            key = (change.symbol, change.kind, change.change_type)
            prev = merged.get(key)
            if prev is None or change.evidence.confidence > prev.evidence.confidence:
                merged[key] = change
        changes = list(merged.values())

    usages = scan_repo(repo, [c.symbol for c in changes])
    findings = evaluate(changes, usages)
    relevant = [f for f in findings if f.verdict != "not_used"]
    blocked = any(f.verdict in {"proven_breaking", "likely_breaking"} for f in relevant)
    return Report(
        dependency=f"{vendor}/{product}",
        from_version=from_version,
        to_version=to_version,
        upstream_changes=len(changes),
        relevant_changes=len(relevant),
        findings=findings,
        release_blocked=blocked,
        document_scope=document_scope,
        spec_verification=spec_verification,
    )
