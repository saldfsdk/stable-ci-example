"""CI integrations for DeviceGuard."""
