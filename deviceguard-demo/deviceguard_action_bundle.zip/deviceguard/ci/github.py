from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterable

from deviceguard.core import run_check
from deviceguard.models import Finding, Report
from deviceguard.reporters import render


def _parse_dependency(dep: str) -> tuple[str, str, str, str]:
    try:
        name, versions = dep.split("@", 1)
        vendor, product = name.split("/", 1)
        from_v, to_v = versions.split("..", 1)
    except ValueError as exc:
        raise ValueError("dependency must use vendor/product@from..to") from exc
    if not all((vendor, product, from_v, to_v)):
        raise ValueError("dependency must use vendor/product@from..to")
    return vendor, product, from_v, to_v


def _bool_env(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _path_from_workspace(value: str | None, workspace: Path, *, required: bool = False) -> Path | None:
    if not value:
        if required:
            raise ValueError("repository path is required")
        return None
    path = Path(value)
    if not path.is_absolute():
        path = workspace / path
    path = path.resolve()
    if not path.exists():
        raise ValueError(f"path does not exist: {path}")
    return path


def _escape_command_data(value: str) -> str:
    return value.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def _escape_command_property(value: str) -> str:
    return (
        _escape_command_data(value)
        .replace(":", "%3A")
        .replace(",", "%2C")
    )


def _emit_annotation(level: str, message: str, *, title: str, file: str | None = None, line: int | None = None, col: int | None = None) -> None:
    props: list[str] = [f"title={_escape_command_property(title)}"]
    if file:
        props.append(f"file={_escape_command_property(file.replace('\\\\', '/').replace('\\', '/'))}")
    if line and line > 0:
        props.append(f"line={line}")
    if col and col > 0:
        props.append(f"col={col}")
    print(f"::{level} {','.join(props)}::{_escape_command_data(message)}")


def _location(finding: Finding) -> tuple[str | None, int | None, int | None]:
    if not finding.usages:
        return None, None, None
    usage = finding.usages[0]
    return usage.file.replace("\\", "/"), usage.line, usage.column


def _finding_message(finding: Finding) -> str:
    change = finding.change
    pieces = [f"{change.symbol} ({change.rule_id}): {change.description or change.change_type}"]
    if change.before:
        pieces.append(f"old={change.before}")
    if change.after:
        pieces.append(f"new={change.after}")
    if change.replacement:
        pieces.append(f"replacement={change.replacement}")
    return " | ".join(pieces)


def emit_annotations(report: Report, *, max_annotations: int = 50) -> int:
    emitted = 0
    for finding in report.findings:
        if finding.verdict == "not_used" or finding.verdict == "compatible":
            continue
        if emitted >= max_annotations:
            print(f"::notice title=DeviceGuard::Annotation limit reached ({max_annotations}); see the job summary for all findings.")
            break
        level = "error" if finding.verdict in {"proven_breaking", "likely_breaking"} else "warning"
        file, line, col = _location(finding)
        _emit_annotation(
            level,
            _finding_message(finding),
            title=f"DeviceGuard {finding.verdict.replace('_', ' ').upper()}",
            file=file,
            line=line,
            col=col,
        )
        emitted += 1
    return emitted


def _md_escape(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def _summary_lines(report: Report, *, fail_on_review: bool) -> list[str]:
    breaking = [f for f in report.findings if f.verdict in {"proven_breaking", "likely_breaking"}]
    reviews = [f for f in report.findings if f.verdict == "review_required"]
    compatible = [f for f in report.findings if f.verdict == "compatible"]
    blocked = report.release_blocked or (fail_on_review and bool(reviews))
    status = "❌ BLOCKED" if blocked else "✅ PASS"

    lines = [
        "# DeviceGuard",
        "",
        f"**{status}** — `{report.dependency}` `{report.from_version}` → `{report.to_version}`",
        "",
        f"- Upstream changes: **{report.upstream_changes}**",
        f"- Relevant to this repository: **{report.relevant_changes}**",
        f"- Breaking: **{len(breaking)}**",
        f"- Review: **{len(reviews)}**",
        f"- Compatible: **{len(compatible)}**",
    ]
    if report.document_scope is not None and report.document_scope.mode == "quectel_version_scoped":
        scope = report.document_scope
        if scope.source_rows is not None and scope.scoped_rows is not None:
            lines.append(f"- Vendor release-note scope: **{scope.scoped_rows}/{scope.source_rows}** cumulative rows")
    if report.spec_verification is not None:
        sv = report.spec_verification
        lines.append(f"- Spec verification: **{sv.verified_diffs}** diffs ({sv.old_commands} old commands → {sv.new_commands} new commands)")

    relevant = [f for f in report.findings if f.verdict != "not_used"]
    if relevant:
        lines += [
            "",
            "| Verdict | Symbol | Rule | Location | Confidence |",
            "|---|---|---|---|---:|",
        ]
        verdict_label = {
            "proven_breaking": "BLOCK",
            "likely_breaking": "LIKELY BREAKING",
            "review_required": "REVIEW",
            "compatible": "PASS",
        }
        for finding in relevant:
            file, line, _ = _location(finding)
            location = f"{file}:{line}" if file and line else "—"
            lines.append(
                "| " + " | ".join([
                    verdict_label.get(finding.verdict, finding.verdict),
                    f"`{_md_escape(finding.change.symbol)}`",
                    f"`{finding.change.rule_id}`",
                    f"`{_md_escape(location)}`" if location != "—" else "—",
                    f"{finding.confidence:.0%}",
                ]) + " |"
            )

    lines += [
        "",
        "DeviceGuard only blocks when the available evidence and source usage justify it; unresolved cases stay REVIEW.",
    ]
    return lines


def write_summary(report: Report, path: Path, *, fail_on_review: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write("\n".join(_summary_lines(report, fail_on_review=fail_on_review)))
        fh.write("\n")


def _write_output(name: str, value: str) -> None:
    output_path = os.environ.get("GITHUB_OUTPUT")
    if not output_path:
        return
    with Path(output_path).open("a", encoding="utf-8") as fh:
        fh.write(f"{name}={value}\n")


def _write_json_report(report: Report) -> Path:
    base = Path(os.environ.get("RUNNER_TEMP") or os.environ.get("TEMP") or ".")
    base.mkdir(parents=True, exist_ok=True)
    path = base / "deviceguard-report.json"
    path.write_text(json.dumps(report.model_dump(), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def main() -> int:
    workspace = Path(os.environ.get("GITHUB_WORKSPACE") or ".").resolve()
    dependency = os.environ.get("DG_DEPENDENCY", "").strip()
    fail_on_review = _bool_env("DG_FAIL_ON_REVIEW", False)
    refresh = _bool_env("DG_REFRESH_VENDOR_DATA", False)
    max_annotations = int(os.environ.get("DG_MAX_ANNOTATIONS", "50"))

    try:
        vendor, product, from_v, to_v = _parse_dependency(dependency)
        repo = _path_from_workspace(os.environ.get("DG_REPO", "."), workspace, required=True)
        vendor_doc = _path_from_workspace(os.environ.get("DG_VENDOR_DOC"), workspace)
        old_spec = _path_from_workspace(os.environ.get("DG_OLD_SPEC"), workspace)
        new_spec = _path_from_workspace(os.environ.get("DG_NEW_SPEC"), workspace)
        report = run_check(
            vendor,
            product,
            from_v,
            to_v,
            repo,
            refresh_vendor_data=refresh,
            vendor_doc=vendor_doc,
            old_spec=old_spec,
            new_spec=new_spec,
        )
    except Exception as exc:
        _emit_annotation("error", str(exc), title="DeviceGuard configuration/error")
        _write_output("blocked", "true")
        return 3

    # Keep the full CLI report in the Actions log.
    render(report)
    emit_annotations(report, max_annotations=max_annotations)

    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary_path:
        write_summary(report, Path(summary_path), fail_on_review=fail_on_review)

    json_path = _write_json_report(report)
    reviews = any(f.verdict == "review_required" for f in report.findings)
    blocked = report.release_blocked or (fail_on_review and reviews)

    _write_output("blocked", "true" if blocked else "false")
    _write_output("upstream-changes", str(report.upstream_changes))
    _write_output("relevant-changes", str(report.relevant_changes))
    _write_output("report-path", str(json_path))

    return 1 if blocked else 0


if __name__ == "__main__":
    raise SystemExit(main())
