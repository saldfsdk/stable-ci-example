from __future__ import annotations
import bisect
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from deviceguard.models import Usage

SOURCE_EXTS = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".ino"}

_STRING_RE = re.compile(r'"(?:\\.|[^"\\])*"')
_PRINTF_RE = re.compile(r'\b(?:snprintf|sprintf|printf)\s*\(', re.I)
_SSCANF_RE = re.compile(r'\bsscanf\s*\(', re.I)
_DEFINE_RE = re.compile(r'^\s*#\s*define\b')
_DEFINE_VALUE_RE = re.compile(r'^\s*#\s*define\s+([A-Za-z_]\w*)\s+([^/\r\n]+?)\s*(?://.*)?$')
_CONST_VALUE_RE = re.compile(
    r'\b(?:static\s+)?(?:const\s+|constexpr\s+)(?:unsigned\s+|signed\s+)?(?:char|short|int|long|float|double|size_t|uint\d+_t|int\d+_t)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);'
)
_NUM_RE = re.compile(r'^[-+]?\d+(?:\.\d+)?$')
_PLACEHOLDER_RE = re.compile(r'%(?!%)(?:[-+0 #]*)(?:\d+|\*)?(?:\.\d+)?(?:hh|h|ll|l|j|z|t|L)?[diuoxXfFeEgGaAcsp]')
_FUNC_DEF_RE = re.compile(
    r'(?m)^[ \t]*(?P<header>(?:(?:static|inline|extern|constexpr)\s+)*(?:[A-Za-z_]\w*(?:\s+|\s*\*\s*))+?)'
    r'(?P<name>[A-Za-z_]\w*)\s*\((?P<params>[^;{}()]*)\)\s*\{'
)
_CONTROL_NAMES = {"if", "for", "while", "switch", "catch"}


@dataclass
class _FunctionInfo:
    name: str
    params: list[str]
    is_static: bool
    start_line: int  # zero-based inclusive
    end_line: int    # zero-based inclusive


@dataclass
class _FileRecord:
    path: Path
    rel: str
    text: str
    lines: list[str]
    constants: dict[str, str]
    functions: list[_FunctionInfo]


def _kind(line: str, symbol: str) -> tuple[str, float]:
    if symbol.startswith(("#", "+", "%")) and _SSCANF_RE.search(line):
        return "response_parser", 0.98
    if _PRINTF_RE.search(line):
        return "format_string", 0.98
    if _DEFINE_RE.search(line):
        return "macro", 0.95
    if _STRING_RE.search(line):
        return "literal", 1.0
    return "text", 0.80


def _strip_scalar(token: str) -> str:
    token = token.strip()
    token = re.sub(r'^\((?:unsigned\s+|signed\s+)?(?:char|short|int|long|float|double|size_t|uint\d+_t|int\d+_t)\)\s*', '', token)
    return token.strip()


def _resolve_scalar(token: str, constants: dict[str, str], *, depth: int = 0) -> tuple[str | None, str | None]:
    if depth > 5:
        return None, None
    token = _strip_scalar(token)
    if _NUM_RE.fullmatch(token):
        return token, "literal"
    if token in constants:
        value, origin = _resolve_scalar(constants[token], constants, depth=depth + 1)
        if value is not None:
            return value, f"constant {token}" if origin == "literal" else f"constant {token} → {origin}"
    return None, None


def _collect_constants(text: str) -> dict[str, str]:
    constants: dict[str, str] = {}
    for line in text.splitlines():
        dm = _DEFINE_VALUE_RE.match(line)
        if dm:
            name, value = dm.group(1), dm.group(2).strip()
            if "(" not in name:
                constants[name] = value
        for cm in _CONST_VALUE_RE.finditer(line):
            constants[cm.group(1)] = cm.group(2).strip()
    return constants


def _split_top_level(s: str) -> list[str]:
    out: list[str] = []
    start = 0
    depth = 0
    in_string = False
    escape = False
    for i, ch in enumerate(s):
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch in "([{":
            depth += 1
        elif ch in ")] }".replace(" ", "") and depth:
            depth -= 1
        elif ch == "," and depth == 0:
            out.append(s[start:i].strip())
            start = i + 1
    out.append(s[start:].strip())
    return out


def _statement(lines: list[str], idx: int) -> str:
    """Collect a small C/C++ statement around a hit so multi-line calls work."""
    start = idx
    for j in range(idx, max(-1, idx - 6), -1):
        start = j
        if j < idx and (";" in lines[j] or "{" in lines[j] or "}" in lines[j]):
            start = j + 1
            break
    end = idx
    for j in range(idx, min(len(lines), idx + 7)):
        end = j
        if ";" in lines[j]:
            break
    return " ".join(x.strip() for x in lines[start:end + 1])


def _extract_call_args(statement: str, func: str) -> list[str] | None:
    m = re.search(rf'\b{re.escape(func)}\s*\(', statement, re.I)
    if not m:
        return None
    i = m.end()
    depth = 1
    in_string = False
    escape = False
    while i < len(statement):
        ch = statement[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return _split_top_level(statement[m.end():i])
        i += 1
    return None


def _decode_c_string(token: str) -> str | None:
    token = token.strip()
    parts = _STRING_RE.findall(token)
    if not parts:
        return None
    value = ""
    for part in parts:
        try:
            value += bytes(part[1:-1], "utf-8").decode("unicode_escape")
        except UnicodeDecodeError:
            value += part[1:-1]
    return value


def _command_args_from_literal(fmt: str, symbol: str) -> list[dict[str, Any]] | None:
    pos = fmt.find(symbol)
    if pos < 0:
        return None
    tail = fmt[pos + len(symbol):]
    if not tail.startswith("="):
        return []
    raw = tail[1:]
    return [{"present": True, "value": x.strip().strip("'\"") or None, "source": "literal"} for x in raw.split(",")]


def _printf_command_args(statement: str, symbol: str, constants: dict[str, str]) -> list[dict[str, Any]] | None:
    fm = re.search(r'\b(snprintf|sprintf|printf)\s*\(', statement, re.I)
    if not fm:
        return None
    func = fm.group(1).lower()
    args = _extract_call_args(statement, func)
    if not args:
        return None
    fmt_index = {"snprintf": 2, "sprintf": 1, "printf": 0}[func]
    if len(args) <= fmt_index:
        return None
    fmt = _decode_c_string(args[fmt_index])
    if fmt is None or symbol not in fmt:
        return None
    pos = fmt.find(symbol)
    tail = fmt[pos + len(symbol):]
    if not tail.startswith("="):
        return []

    c_values = args[fmt_index + 1:]
    placeholder_cursor = 0
    command_args: list[dict[str, Any]] = []
    for segment in tail[1:].split(","):
        ph = list(_PLACEHOLDER_RE.finditer(segment))
        if not ph:
            token = segment.strip().strip("'\"")
            command_args.append({"present": True, "value": token or None, "source": "format literal"})
            continue
        if len(ph) == 1 and placeholder_cursor < len(c_values):
            c_token = c_values[placeholder_cursor].strip()
            value, origin = _resolve_scalar(c_token, constants)
            command_args.append({
                "present": True,
                "value": value,
                "source": origin or f"runtime {c_token}",
                "expression": c_token,
            })
        else:
            command_args.append({"present": True, "value": None, "source": "complex format expression"})
        placeholder_cursor += len(ph)
    return command_args


def _line_starts(text: str) -> list[int]:
    starts = [0]
    for m in re.finditer(r'\n', text):
        starts.append(m.end())
    return starts


def _char_to_line(starts: list[int], pos: int) -> int:
    return max(0, bisect.bisect_right(starts, pos) - 1)


def _matching_brace(text: str, brace_pos: int) -> int | None:
    depth = 0
    in_string = False
    in_char = False
    escape = False
    i = brace_pos
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if in_string or in_char:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif in_string and ch == '"':
                in_string = False
            elif in_char and ch == "'":
                in_char = False
            i += 1
            continue
        if ch == '"':
            in_string = True
        elif ch == "'":
            in_char = True
        elif ch == "/" and nxt == "/":
            nl = text.find("\n", i + 2)
            i = len(text) if nl < 0 else nl + 1
            continue
        elif ch == "/" and nxt == "*":
            end = text.find("*/", i + 2)
            i = len(text) if end < 0 else end + 2
            continue
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return None


def _param_names(raw: str) -> list[str]:
    params: list[str] = []
    for part in _split_top_level(raw):
        token = part.strip()
        if not token or token == "void":
            continue
        token = token.split("=", 1)[0].strip()
        names = re.findall(r'[A-Za-z_]\w*', token)
        if names:
            params.append(names[-1])
    return params


def _find_functions(text: str) -> list[_FunctionInfo]:
    starts = _line_starts(text)
    funcs: list[_FunctionInfo] = []
    for m in _FUNC_DEF_RE.finditer(text):
        name = m.group("name")
        if name in _CONTROL_NAMES:
            continue
        brace_pos = text.find("{", m.start(), m.end())
        end_pos = _matching_brace(text, brace_pos)
        if end_pos is None:
            continue
        header = m.group("header") or ""
        funcs.append(_FunctionInfo(
            name=name,
            params=_param_names(m.group("params") or ""),
            is_static=bool(re.search(r'\bstatic\b', header)),
            start_line=_char_to_line(starts, m.start()),
            end_line=_char_to_line(starts, end_pos),
        ))
    return funcs


def _enclosing_function(functions: list[_FunctionInfo], idx: int) -> _FunctionInfo | None:
    for fn in functions:
        if fn.start_line <= idx <= fn.end_line:
            return fn
    return None


def _usage_metadata(
    lines: list[str], idx: int, line: str, kind: str, symbol: str,
    constants: dict[str, str], function: _FunctionInfo | None,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    if kind == "format_string":
        args = _printf_command_args(_statement(lines, idx), symbol, constants)
        if args is not None:
            metadata["command_args"] = args
            if function is not None:
                metadata["enclosing_function"] = {
                    "name": function.name,
                    "params": function.params,
                    "static": function.is_static,
                    "body_line": idx + 1,
                }
    elif kind in {"literal", "macro"}:
        for raw in _STRING_RE.findall(line):
            value = _decode_c_string(raw)
            if value and symbol in value:
                args = _command_args_from_literal(value, symbol)
                if args is not None:
                    metadata["command_args"] = args
                    break
    return metadata


def _wrapper_call_sites(record: _FileRecord, fn: _FunctionInfo) -> list[tuple[int, str, list[str]]]:
    """Find direct same-file calls to a static wrapper, excluding its definition body."""
    if not fn.is_static:
        return []
    # Taking a wrapper address means we cannot enumerate all calls conservatively.
    if re.search(rf'&\s*{re.escape(fn.name)}\b', record.text):
        return []
    sites: list[tuple[int, str, list[str]]] = []
    for idx, line in enumerate(record.lines):
        if fn.start_line <= idx <= fn.end_line:
            continue
        if not re.search(rf'\b{re.escape(fn.name)}\s*\(', line):
            continue
        statement = _statement(record.lines, idx)
        args = _extract_call_args(statement, fn.name)
        if args is None:
            continue
        # Skip prototypes/declarations (a call statement must end in ';' and not
        # look like a type declaration immediately before the function name).
        prefix = statement.split(fn.name, 1)[0].strip()
        if re.search(r'\b(?:void|char|short|int|long|float|double|size_t|uint\d+_t|int\d+_t)\s+\*?$', prefix):
            continue
        sites.append((idx, line.strip(), args))
    return sites


def _propagate_static_wrapper_usage(record: _FileRecord, usage: Usage) -> list[Usage] | None:
    meta = usage.metadata or {}
    fn_meta = meta.get("enclosing_function")
    command_args = meta.get("command_args")
    if not isinstance(fn_meta, dict) or not fn_meta.get("static") or not isinstance(command_args, list):
        return None
    fn = next((f for f in record.functions if f.name == fn_meta.get("name") and f.start_line <= usage.line - 1 <= f.end_line), None)
    if fn is None or not fn.params:
        return None

    # Only propagate when at least one unresolved printf argument is exactly a
    # wrapper parameter. This intentionally stops after one call edge.
    param_refs: dict[int, int] = {}
    for arg_index, item in enumerate(command_args):
        if not isinstance(item, dict) or item.get("value") is not None:
            continue
        expr = str(item.get("expression") or "").strip()
        if expr in fn.params:
            param_refs[arg_index] = fn.params.index(expr)
    if not param_refs:
        return None

    call_sites = _wrapper_call_sites(record, fn)
    if not call_sites:
        return None

    derived: list[Usage] = []
    for idx, excerpt, call_args in call_sites:
        cloned = [dict(x) if isinstance(x, dict) else x for x in command_args]
        for cmd_index, param_index in param_refs.items():
            item = cloned[cmd_index]
            if param_index >= len(call_args):
                item["value"] = None
                item["source"] = f"wrapper {fn.name}() missing arg"
                continue
            token = call_args[param_index].strip()
            value, origin = _resolve_scalar(token, record.constants)
            item["value"] = value
            item["source"] = (
                f"wrapper {fn.name}({fn.params[param_index]}) ← {origin}"
                if value is not None and origin
                else f"wrapper {fn.name}({fn.params[param_index]}) ← runtime {token}"
            )
            item["expression"] = token
        derived.append(Usage(
            file=record.rel,
            line=idx + 1,
            column=max(1, record.lines[idx].find(fn.name) + 1),
            kind="format_string",
            excerpt=excerpt[:240],
            confidence=min(usage.confidence, 0.96),
            metadata={
                "command_args": cloned,
                "wrapper": {
                    "function": fn.name,
                    "body_file": usage.file,
                    "body_line": usage.line,
                    "depth": 1,
                },
            },
        ))
    return derived


def scan_repo(root: Path, symbols: list[str]) -> dict[str, list[Usage]]:
    symbols = list(dict.fromkeys(symbols))
    out: dict[str, list[Usage]] = {s: [] for s in symbols}
    records: dict[str, _FileRecord] = {}

    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in SOURCE_EXTS:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = str(path.relative_to(root))
        constants = _collect_constants(text)
        lines = text.splitlines()
        functions = _find_functions(text)
        record = _FileRecord(path=path, rel=rel, text=text, lines=lines, constants=constants, functions=functions)
        records[rel] = record

        for idx, line in enumerate(lines):
            lineno = idx + 1
            function = _enclosing_function(functions, idx)
            for symbol in symbols:
                if symbol in line:
                    kind, confidence = _kind(line, symbol)
                    out[symbol].append(Usage(
                        file=rel, line=lineno,
                        column=line.index(symbol) + 1, kind=kind,
                        excerpt=line.strip()[:240], confidence=confidence,
                        metadata=_usage_metadata(lines, idx, line, kind, symbol, constants, function),
                    ))

    # v0.9: one-edge propagation through private/static wrappers. A static
    # wrapper's call sites are enumerable within its translation unit, so the
    # unresolved body usage can be replaced with call-site-specific facts.
    for symbol, usages in list(out.items()):
        rewritten: list[Usage] = []
        for usage in usages:
            record = records.get(usage.file)
            derived = _propagate_static_wrapper_usage(record, usage) if record is not None else None
            if derived:
                rewritten.extend(derived)
            else:
                rewritten.append(usage)
        out[symbol] = rewritten
    return out
