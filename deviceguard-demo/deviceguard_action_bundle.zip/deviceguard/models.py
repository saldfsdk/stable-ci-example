from __future__ import annotations
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field

ChangeType = Literal[
    "command_removed", "command_renamed", "signature_changed",
    "response_changed", "behavior_changed", "command_added",
    "parameter_optional_to_required", "parameter_required_to_optional",
    "enum_changed", "range_changed", "required_parameter_added",
    "optional_parameter_added", "parameter_removed", "parameter_reordered"
]
Verdict = Literal["proven_breaking", "likely_breaking", "review_required", "compatible", "not_used"]

class Evidence(BaseModel):
    source: str
    source_type: Literal["official_spec", "migration_note", "vendor_document", "manual_fixture"]
    confidence: float = Field(ge=0.0, le=1.0)

class InterfaceChange(BaseModel):
    rule_id: str
    symbol: str
    kind: Literal["command", "response", "behavior", "parameter"] = "command"
    change_type: ChangeType
    breaking: bool
    before: Optional[str] = None
    after: Optional[str] = None
    replacement: Optional[str] = None
    description: str = ""
    evidence: Evidence
    metadata: dict[str, Any] = Field(default_factory=dict)

class Usage(BaseModel):
    file: str
    line: int
    column: int
    kind: Literal["literal", "format_string", "response_parser", "macro", "text"]
    excerpt: str
    confidence: float = Field(ge=0.0, le=1.0)
    metadata: dict[str, Any] = Field(default_factory=dict)

class Finding(BaseModel):
    change: InterfaceChange
    usages: list[Usage] = []
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)

class DocumentScope(BaseModel):
    mode: Literal["generic", "quectel_version_scoped"]
    detected_from: Optional[str] = None
    detected_to: Optional[str] = None
    source_rows: Optional[int] = None
    scoped_rows: Optional[int] = None

class SpecVerification(BaseModel):
    old_spec: str
    new_spec: str
    old_commands: int
    new_commands: int
    verified_diffs: int

class Report(BaseModel):
    dependency: str
    from_version: str
    to_version: str
    upstream_changes: int
    relevant_changes: int
    findings: list[Finding]
    release_blocked: bool
    document_scope: Optional[DocumentScope] = None
    spec_verification: Optional[SpecVerification] = None
