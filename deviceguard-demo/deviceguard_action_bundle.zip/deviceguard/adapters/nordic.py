from __future__ import annotations

"""Nordic Serial Modem adapter.

v0.2 moves the Nordic change set from a handwritten fixture to an automatically
parsed official migration document. The adapter fetches Nordic's public RST
migration notes, caches them locally, and conservatively converts explicit
rename/removal/syntax/response changes into DeviceGuard IR.

If the network is unavailable and no cache exists, a tiny seed fallback keeps
the prototype usable. Findings produced from the fallback carry lower evidence
confidence than findings parsed from the official migration document.
"""

import os
import re
import urllib.error
import urllib.request
from pathlib import Path

from deviceguard.models import Evidence, InterfaceChange

DOC_URL = (
    "https://raw.githubusercontent.com/nrfconnect/ncs-serial-modem/main/"
    "doc/releases/migration_notes_ncs_slm_v3.1.x.rst"
)
DISPLAY_URL = (
    "https://github.com/nrfconnect/ncs-serial-modem/blob/main/"
    "doc/releases/migration_notes_ncs_slm_v3.1.x.rst"
)

_AT = r"AT[#%+][A-Z0-9_]+"
_RESP = r"#[A-Z0-9_]+:"


def _cache_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return root / "DeviceGuard" / "cache"
    root = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return root / "deviceguard"


def _cache_file() -> Path:
    return _cache_dir() / "nordic_serial_modem_migration_3_1.rst"


def _fetch_official_text(timeout: float = 8.0) -> str:
    request = urllib.request.Request(
        DOC_URL,
        headers={"User-Agent": "deviceguard/0.0.2 (+https://github.com/)"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
    return raw.decode("utf-8", errors="replace")


def load_official_text(*, refresh: bool = False) -> tuple[str | None, str]:
    """Return (text, mode) where mode is live/cache/unavailable."""
    cache = _cache_file()

    if not refresh and cache.exists():
        try:
            return cache.read_text(encoding="utf-8"), "cache"
        except OSError:
            pass

    try:
        text = _fetch_official_text()
        cache.parent.mkdir(parents=True, exist_ok=True)
        try:
            cache.write_text(text, encoding="utf-8")
        except OSError:
            pass
        return text, "live"
    except (OSError, urllib.error.URLError, TimeoutError):
        if cache.exists():
            try:
                return cache.read_text(encoding="utf-8"), "cache"
            except OSError:
                pass
        return None, "unavailable"


def _evidence(confidence: float = 1.0) -> Evidence:
    return Evidence(
        source=DISPLAY_URL,
        source_type="migration_note",
        confidence=confidence,
    )


def _change(
    *,
    rule_id: str,
    symbol: str,
    change_type: str,
    breaking: bool,
    description: str,
    kind: str = "command",
    before: str | None = None,
    after: str | None = None,
    replacement: str | None = None,
    confidence: float = 1.0,
) -> InterfaceChange:
    return InterfaceChange(
        rule_id=rule_id,
        symbol=symbol,
        kind=kind,
        change_type=change_type,
        breaking=breaking,
        description=description,
        before=before,
        after=after,
        replacement=replacement,
        evidence=_evidence(confidence),
    )


def _dedupe(items: list[InterfaceChange]) -> list[InterfaceChange]:
    """Collapse duplicate discoveries from multiple sections of the vendor doc.

    Migration notes often describe the same interface change twice (for example
    once in a command-specific section and once in a response-summary section).
    For signature/response changes we retain the most structurally detailed
    representation instead of emitting duplicate findings.
    """
    grouped: dict[tuple[str, str, str], InterfaceChange] = {}
    order: list[tuple[str, str, str]] = []

    def score(item: InterfaceChange) -> tuple[int, int]:
        after = item.after or ""
        before = item.before or ""
        return (after.count("<") + before.count("<"), len(after) + len(before))

    for item in items:
        key = (item.symbol, item.kind, item.change_type)
        if key not in grouped:
            grouped[key] = item
            order.append(key)
            continue
        if item.change_type in {"signature_changed", "response_changed"}:
            if score(item) > score(grouped[key]):
                grouped[key] = item
        # Other duplicate discoveries are intentionally ignored.

    return [grouped[k] for k in order]


def _nearest_command_prefix(text: str, pos: int, lookback: int = 700) -> str | None:
    window = text[max(0, pos - lookback):pos]
    commands = re.findall(r"``(" + _AT + r")``", window)
    return commands[-1] if commands else None


def parse_migration_text(text: str) -> list[InterfaceChange]:
    """Conservatively parse explicit interface changes from Nordic's RST notes.

    The parser intentionally ignores changes that cannot be mapped to a stable
    command/response symbol with high confidence. Those can later be added as
    REVIEW rules without weakening the precision of BLOCK findings.
    """
    items: list[InterfaceChange] = []

    # 1) Explicit command renames: ``AT#OLD`` to ``AT#NEW``
    for match in re.finditer(
        r"``(?P<old>" + _AT + r")``\s+to\s+``(?P<new>" + _AT + r")``",
        text,
    ):
        old, new = match.group("old"), match.group("new")
        items.append(_change(
            rule_id="DG1002",
            symbol=old,
            change_type="command_renamed",
            breaking=True,
            replacement=new,
            description=f"Command renamed to {new}.",
        ))

    # 2) Direct removed command statements.
    removal_patterns = [
        r"Removed\s+``(?P<cmd>" + _AT + r")``",
        r"``(?P<cmd>" + _AT + r")``\s+-\s+Socket selection is no longer needed",
    ]
    for pattern in removal_patterns:
        for match in re.finditer(pattern, text, flags=re.I):
            cmd = match.group("cmd")
            items.append(_change(
                rule_id="DG1001",
                symbol=cmd,
                change_type="command_removed",
                breaking=True,
                description="Command removed in the target interface.",
            ))

    # 3) Removed-command list sections. Parse bullets conservatively so that the
    #    next top-level bullet (for example an updated command) is not mistaken
    #    for another removed command.
    lines = text.splitlines()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "* Removed commands:":
            # Nested bullets only, until the next top-level bullet/section.
            for nxt in lines[i + 1:i + 20]:
                if nxt.startswith("* ") or (nxt and not nxt.startswith((" ", "\t"))):
                    break
                m = re.match(r"\s+\*\s+``(" + _AT + r")``", nxt)
                if m:
                    items.append(_change(
                        rule_id="DG1001", symbol=m.group(1),
                        change_type="command_removed", breaking=True,
                        description="Command removed in the target interface.",
                    ))

        if stripped in {
            "The following AT commands have been removed:",
            "This includes the removal of the following AT commands:",
        }:
            for nxt in lines[i + 1:i + 20]:
                # Ignore blank lead-in lines, then consume the consecutive bullet list.
                if not nxt.strip():
                    continue
                m = re.match(r"\s*\*\s+``(" + _AT + r")``", nxt)
                if m:
                    items.append(_change(
                        rule_id="DG1001", symbol=m.group(1),
                        change_type="command_removed", breaking=True,
                        description="Command removed in the target interface.",
                    ))
                    continue
                break

    # 4) Compact removal sentences such as "including ``AT#XFTP`` and ``AT#XTFTP`` commands".
    for match in re.finditer(r"including\s+(?P<body>[^\n]{0,180})\s+commands", text, flags=re.I):
        if "Removed" not in text[max(0, match.start() - 80):match.start() + 20] and "removed" not in text[max(0, match.start() - 80):match.start() + 20]:
            continue
        for cmd in re.findall(r"``(" + _AT + r")``", match.group("body")):
            items.append(_change(
                rule_id="DG1001",
                symbol=cmd,
                change_type="command_removed",
                breaking=True,
                description="Command removed in the target interface.",
            ))

    # 5) Old/New command syntax pairs. Associate the pair with the nearest explicit AT command.
    syntax_re = re.compile(
        r"Old syntax(?:\s+for[^:]+)?\s*[:-]\s*``(?P<old>AT[^`]+)``"
        r"(?P<middle>.{0,900}?)"
        r"New syntax(?:\s+for[^:]+)?\s*[:-]\s*``(?P<new>AT[^`]+)``",
        flags=re.S,
    )
    for match in syntax_re.finditer(text):
        cmd = _nearest_command_prefix(text, match.start())
        if not cmd:
            # Fallback to command prefix contained in the syntax itself.
            found = re.match(r"(" + _AT + r")", match.group("old"))
            cmd = found.group(1) if found else None
        if not cmd:
            continue
        old = match.group("old").strip()
        new = match.group("new").strip()
        if old == new:
            continue
        items.append(_change(
            rule_id="DG1004",
            symbol=cmd,
            change_type="signature_changed",
            breaking=True,
            before=old,
            after=new,
            description="Command syntax/signature changed.",
        ))

    # Special-case commands with multiple documented new syntax variants (notably XSEND).
    # The generic pair above catches the first pair; this pattern catches the canonical
    # old syntax and combines the documented string/data-mode forms into one summary.
    for match in re.finditer(
        r"``(?P<cmd>" + _AT + r")`` command parameter changes:(?P<body>.{0,1800}?)(?=\n\* ``AT|\n[A-Z][^\n]+\n[-~]{3,}|\Z)",
        text,
        flags=re.S,
    ):
        cmd, body = match.group("cmd"), match.group("body")
        old_match = re.search(r"Old syntax\s*-\s*``(?P<old>AT[^`]+)``", body)
        new_forms = re.findall(r"New syntax[^:]*:\s*``(?P<new>AT[^`]+)``", body)
        if old_match and new_forms:
            items.append(_change(
                rule_id="DG1004",
                symbol=cmd,
                change_type="signature_changed",
                breaking=True,
                before=old_match.group("old").strip(),
                after=" OR ".join(x.strip() for x in new_forms),
                description="Command parameters/order changed.",
            ))

    # 6) Explicit Old/New response pairs.
    response_pair_re = re.compile(
        r"Old response:\s*``(?P<old>#[A-Z0-9_]+:\s*[^`]+)``"
        r"(?P<middle>.{0,450}?)"
        r"New response:\s*``(?P<new>#[A-Z0-9_]+:\s*[^`]+)``",
        flags=re.S,
    )
    for match in response_pair_re.finditer(text):
        old = match.group("old").strip()
        new = match.group("new").strip()
        prefix_match = re.match(r"(#[A-Z0-9_]+:)", old)
        if not prefix_match:
            continue
        prefix = prefix_match.group(1)
        items.append(_change(
            rule_id="DG1011",
            symbol=prefix,
            kind="response",
            change_type="response_changed",
            breaking=True,
            before=old,
            after=new,
            description="Response shape changed.",
        ))

    # 7) One-line response changes: ``#X...`` (previously ``#X...``)
    one_line_response_re = re.compile(
        r"Response[^\n]{0,140}?``(?P<new>#[A-Z0-9_]+:\s*[^`]+)``\s*"
        r"\(previously(?:\s+just)?\s*``(?P<old>#[A-Z0-9_]+:\s*[^`]+)``\)",
        flags=re.I,
    )
    for match in one_line_response_re.finditer(text):
        old, new = match.group("old").strip(), match.group("new").strip()
        prefix = re.match(r"(#[A-Z0-9_]+:)", old)
        if not prefix:
            continue
        items.append(_change(
            rule_id="DG1011",
            symbol=prefix.group(1),
            kind="response",
            change_type="response_changed",
            breaking=True,
            before=old,
            after=new,
            description="Response shape changed.",
        ))

    # 8) Default AT command terminator is a behavioral compatibility change.
    if "default AT command terminator" in text and "CONFIG_SM_CR_TERMINATION" in text:
        items.append(_change(
            rule_id="DG1200",
            symbol="AT command terminator",
            kind="behavior",
            change_type="behavior_changed",
            breaking=False,
            before="\\r\\n",
            after="\\r",
            description="Default AT command terminator changed.",
        ))

    # 9) HTTP client legacy command removal is phrased as "Removed ``AT#XHTTPCCON``."
    #    This is already covered by direct removal, but we add a replacement hint.
    for item in items:
        if item.symbol == "AT#XHTTPCCON" and item.change_type == "command_removed":
            item.replacement = "socket commands + AT#XHTTPCREQ"
            item.description = "Legacy HTTP connection command removed; HTTP now uses socket-based transport."

    # 10) Upgrade a few well-known migration descriptions with richer summaries.
    for item in items:
        if item.symbol == "AT#XSOCKETSELECT" and item.change_type == "command_removed":
            item.replacement = "handle-based socket commands"
            item.description = "Socket selection removed; operations now take socket handles directly."
        elif item.symbol == "AT#XGPS" and item.change_type == "command_renamed":
            item.description = "GNSS command renamed."

    return _dedupe(items)


def _seed_changes() -> list[InterfaceChange]:
    """Minimal offline fallback, kept deliberately small.

    This is only used when no official document can be fetched and no cache exists.
    It keeps the demo runnable but uses lower evidence confidence.
    """
    ev = Evidence(source=DISPLAY_URL, source_type="manual_fixture", confidence=0.92)
    return [
        InterfaceChange(
            rule_id="DG1001", symbol="AT#XSOCKETSELECT", change_type="command_removed",
            breaking=True,
            description="Socket selection removed; operations now take socket handles directly.",
            replacement="handle-based socket commands", evidence=ev,
        ),
        InterfaceChange(
            rule_id="DG1002", symbol="AT#XGPS", change_type="command_renamed",
            breaking=True, replacement="AT#XGNSS", description="GNSS command renamed.", evidence=ev,
        ),
        InterfaceChange(
            rule_id="DG1004", symbol="AT#XSEND", change_type="signature_changed", breaking=True,
            before="AT#XSEND[=<data>][,<flags>]",
            after="AT#XSEND=<handle>,<mode>,<flags>,...",
            description="Handle/mode were added and parameter order changed.", evidence=ev,
        ),
        InterfaceChange(
            rule_id="DG1011", symbol="#XSEND:", kind="response", change_type="response_changed", breaking=True,
            before="#XSEND: <size>", after="#XSEND: <handle>,<result_type>,<size>",
            description="Response shape expanded.", evidence=ev,
        ),
    ]


def changes(from_version: str, to_version: str, *, refresh: bool = False) -> list[InterfaceChange]:
    # v0.2 initially supports the public migration path used by the prototype.
    if not from_version.startswith("3.1"):
        raise ValueError(
            "Nordic live adapter currently supports the NCS SLM 3.1.x migration path only."
        )

    text, _mode = load_official_text(refresh=refresh)
    if text:
        parsed = parse_migration_text(text)
        if parsed:
            return parsed
    return _seed_changes()
