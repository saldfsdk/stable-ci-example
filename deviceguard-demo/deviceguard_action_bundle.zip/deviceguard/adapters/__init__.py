from . import nordic, espressif

ADAPTERS = {
    ("nordic", "serial-modem"): nordic,
    ("espressif", "esp-at"): espressif,
}
