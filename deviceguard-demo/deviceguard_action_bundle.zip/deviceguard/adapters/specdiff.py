from __future__ import annotations

"""Conservative old/new AT-command manual diffing.

v0.7 extends the deterministic spec diff beyond raw syntax strings. It extracts
parameter required/optional state from square-bracket syntax, plus simple
parameter ranges and enumerated values from Quectel-style ``Parameter``
sections. Ambiguous prose is ignored rather than guessed.
"""

import re
from dataclasses import dataclass, field
from pathlib import Path

from deviceguard.adapters.document import load_document
from deviceguard.models import Evidence, InterfaceChange, SpecVerification

_CMD_RE = re.compile(r"\bAT(?:\+|#|%)[A-Z0-9_]+\b", re.I)
_RESP_RE = re.compile(r"^\s*([+#%][A-Z0-9_]+:)\s*(.*)$", re.I)
_PARAM_TOKEN_RE = re.compile(r"<([A-Za-z0-9_./-]+)>")
_PARAM_LINE_RE = re.compile(r"^\s*<([A-Za-z0-9_./-]+)>\s*(.*)$")
_RANGE_RE = re.compile(
    r"(?:range\s*(?::|is)?\s*|in\s+range\s+)([-+]?\d+(?:\.\d+)?)\s*(?:to|[-~])\s*([-+]?\d+(?:\.\d+)?)",
    re.I,
)
_ENUM_LINE_RE = re.compile(r"^(?:[-•]\s*)?([-+]?\d+)\s+(.+)$")
_MODE_MARKERS = ("write command", "execution command", "read command", "test command", "command syntax", "syntax")
_STOP_MARKERS = ("example", "note", "reference", "maximum response time", "characteristics")


@dataclass
class ParameterSpec:
    name: str
    required: bool | None = None
    value_range: tuple[str, str] | None = None
    enum_values: set[str] = field(default_factory=set)


@dataclass
class CommandSpec:
    command: str
    syntaxes: set[str] = field(default_factory=set)
    responses: set[str] = field(default_factory=set)
    parameters: dict[str, ParameterSpec] = field(default_factory=dict)


@dataclass
class SpecSnapshot:
    commands: dict[str, CommandSpec]


def _norm(s: str) -> str:
    s = s.replace("＜", "<").replace("＞", ">")
    s = s.replace("［", "[").replace("］", "]")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _clean_lines(text: str) -> list[str]:
    return [_norm(x) for x in text.splitlines() if _norm(x)]


def _heading_command(line: str) -> str | None:
    m = _CMD_RE.search(line)
    if not m:
        return None
    cmd = m.group(0).upper()
    tail = line[m.end():].strip()
    if tail.startswith(("=", "?")):
        return None
    if "<" in tail[:12] or "," in tail[:12]:
        return None
    return cmd


def _parameter_requiredness(syntax: str, command: str) -> dict[str, bool]:
    """Return parameter requiredness from one explicit syntax string.

    Quectel manuals define square brackets as optional command portions. We only
    use this deterministic notation; prose such as "can be omitted" is not
    needed for the proof.
    """
    if not syntax.upper().startswith(command.upper()):
        return {}
    suffix = syntax[len(command):]
    depth = 0
    out: dict[str, bool] = {}
    i = 0
    while i < len(suffix):
        ch = suffix[i]
        if ch == "[":
            depth += 1
            i += 1
            continue
        if ch == "]":
            depth = max(0, depth - 1)
            i += 1
            continue
        if ch == "<":
            end = suffix.find(">", i + 1)
            if end != -1:
                name = suffix[i + 1:end]
                if re.fullmatch(r"[A-Za-z0-9_./-]+", name):
                    required = depth == 0
                    # If a parameter appears in multiple forms, required wins
                    # only when every observed form requires it. We start with
                    # the current form and merge more conservatively below.
                    out[name] = required
                i = end + 1
                continue
        i += 1
    return out


def _merge_syntax_parameters(spec: CommandSpec) -> None:
    per_param: dict[str, list[bool]] = {}
    for syntax in spec.syntaxes:
        for name, required in _parameter_requiredness(syntax, spec.command).items():
            per_param.setdefault(name, []).append(required)
    for name, states in per_param.items():
        p = spec.parameters.setdefault(name, ParameterSpec(name=name))
        # A parameter is deterministically required only if every syntax form
        # containing it requires it; otherwise treat it as optional.
        p.required = bool(states) and all(states)


def _parse_parameter_metadata(lines: list[str], commands: dict[str, CommandSpec]) -> None:
    current_cmd: str | None = None
    in_parameter_section = False
    current_param: str | None = None

    for line in lines:
        heading = _heading_command(line)
        if heading is not None:
            current_cmd = heading if heading in commands else None
            in_parameter_section = False
            current_param = None
            continue
        if current_cmd is None:
            continue

        low = line.lower()
        if low == "parameter" or low == "parameters":
            in_parameter_section = True
            current_param = None
            continue
        if in_parameter_section and any(low.startswith(marker) for marker in _STOP_MARKERS):
            in_parameter_section = False
            current_param = None
            continue
        if not in_parameter_section:
            continue

        pm = _PARAM_LINE_RE.match(line)
        if pm:
            name, desc = pm.group(1), pm.group(2)
            current_param = name
            p = commands[current_cmd].parameters.setdefault(name, ParameterSpec(name=name))
            rm = _RANGE_RE.search(desc)
            if rm:
                p.value_range = (rm.group(1), rm.group(2))
            # Inline enumerations, e.g. "0 Disable; 1 Enable", are intentionally
            # not guessed here; explicit following value rows are safer.
            continue

        if current_param:
            p = commands[current_cmd].parameters[current_param]
            rm = _RANGE_RE.search(line)
            if rm:
                p.value_range = (rm.group(1), rm.group(2))
            em = _ENUM_LINE_RE.match(line)
            if em:
                p.enum_values.add(em.group(1))


def parse_spec_text(text: str) -> SpecSnapshot:
    lines = _clean_lines(text)
    commands: dict[str, CommandSpec] = {}
    current: str | None = None
    syntax_mode = False
    response_mode = False

    for line in lines:
        low = line.lower()
        heading = _heading_command(line)
        if heading is not None:
            current = heading
            commands.setdefault(current, CommandSpec(command=current))
            syntax_mode = False
            response_mode = False
            continue

        if current is None:
            continue

        if any(marker in low for marker in _MODE_MARKERS):
            syntax_mode = True
            response_mode = False
            m = _CMD_RE.search(line)
            if m and m.group(0).upper() == current:
                syntax = _norm(line[m.start():])
                if syntax != current:
                    commands[current].syntaxes.add(syntax)
            continue

        if low == "response" or low.startswith("response ") or low.startswith("response:"):
            response_mode = True
            syntax_mode = False
            continue

        if any(low.startswith(marker) for marker in _STOP_MARKERS):
            syntax_mode = False
            response_mode = False

        if line.upper().startswith(current):
            suffix = line[len(current):]
            if syntax_mode or suffix.startswith(("=", "?")):
                commands[current].syntaxes.add(_norm(line))
                continue

        rm = _RESP_RE.match(line)
        if rm:
            expected = current[2:] + ":"
            prefix = rm.group(1).upper()
            if response_mode or prefix == expected.upper():
                commands[current].responses.add(_norm(line))
                continue

    commands = {k: v for k, v in commands.items() if v.syntaxes or v.responses}
    for spec in commands.values():
        _merge_syntax_parameters(spec)
    _parse_parameter_metadata(lines, commands)
    return SpecSnapshot(commands=commands)


def parse_spec(path: Path) -> SpecSnapshot:
    return parse_spec_text(load_document(path))


def _response_symbol(command: str, responses: set[str]) -> str:
    for response in sorted(responses):
        m = _RESP_RE.match(response)
        if m:
            return m.group(1).upper()
    return command[2:] + ":"


def _ev(old_path: Path, new_path: Path) -> Evidence:
    return Evidence(source=f"{old_path} -> {new_path}", source_type="official_spec", confidence=0.99)


def _num(v: str) -> float | None:
    try:
        return float(v)
    except ValueError:
        return None


def _range_narrowed(old: tuple[str, str], new: tuple[str, str]) -> bool:
    a0, a1, b0, b1 = _num(old[0]), _num(old[1]), _num(new[0]), _num(new[1])
    if None in {a0, a1, b0, b1}:
        return old != new
    return b0 > a0 or b1 < a1


def _parameter_order(spec: CommandSpec) -> list[str]:
    if not spec.syntaxes:
        return []
    # Prefer the richest write syntax; it usually contains the full argument contract.
    syntax = max(spec.syntaxes, key=lambda x: (x.count("<"), len(x)))
    return _PARAM_TOKEN_RE.findall(syntax[len(spec.command):])


def _parameter_diffs(cmd: str, a: CommandSpec, b: CommandSpec, ev: Evidence) -> list[InterfaceChange]:
    out: list[InterfaceChange] = []

    old_names = set(a.parameters)
    new_names = set(b.parameters)
    for name in sorted(new_names - old_names):
        p = b.parameters[name]
        if p.required is True:
            new_order = _parameter_order(b)
            out.append(InterfaceChange(
                rule_id="DG1004", symbol=cmd, kind="parameter",
                change_type="required_parameter_added", breaking=True,
                before=f"<{name}> absent", after=f"<{name}> required",
                description=f"Old/new manuals prove that required parameter <{name}> was added.", evidence=ev,
                metadata={
                    "parameter": name,
                    "parameter_index": (new_order.index(name) if name in new_order else None),
                },
            ))
        else:
            out.append(InterfaceChange(
                rule_id="DG1023", symbol=cmd, kind="parameter",
                change_type="optional_parameter_added", breaking=False,
                before=f"<{name}> absent", after=f"<{name}> optional",
                description=f"Optional parameter <{name}> was added; existing calls remain valid.", evidence=ev,
            ))

    for name in sorted(old_names - new_names):
        out.append(InterfaceChange(
            rule_id="DG1003", symbol=cmd, kind="parameter",
            change_type="parameter_removed", breaking=True,
            before=f"<{name}> present", after=f"<{name}> removed",
            description=f"Old/new manuals prove that parameter <{name}> was removed from the command contract.", evidence=ev,
        ))

    old_order = [x for x in _parameter_order(a) if x in new_names]
    new_order = [x for x in _parameter_order(b) if x in old_names]
    if old_order and new_order and old_order != new_order and set(old_order) == set(new_order):
        out.append(InterfaceChange(
            rule_id="DG1005", symbol=cmd, kind="parameter",
            change_type="parameter_reordered", breaking=True,
            before="parameter order: " + ", ".join(old_order),
            after="parameter order: " + ", ".join(new_order),
            description="Old/new manuals prove that existing parameters were reordered.", evidence=ev,
        ))

    for name in sorted(old_names & new_names):
        old = a.parameters[name]
        new = b.parameters[name]

        if old.required is False and new.required is True:
            new_order = _parameter_order(b)
            out.append(InterfaceChange(
                rule_id="DG1006", symbol=cmd, kind="parameter",
                change_type="parameter_optional_to_required", breaking=True,
                before=f"<{name}> optional", after=f"<{name}> required",
                description=f"Old/new manuals prove that parameter <{name}> changed from optional to required.",
                evidence=ev,
                metadata={
                    "parameter": name,
                    "parameter_index": (new_order.index(name) if name in new_order else None),
                },
            ))
        elif old.required is True and new.required is False:
            out.append(InterfaceChange(
                rule_id="DG1022", symbol=cmd, kind="parameter",
                change_type="parameter_required_to_optional", breaking=False,
                before=f"<{name}> required", after=f"<{name}> optional",
                description=f"Parameter <{name}> became optional; existing calls remain valid.",
                evidence=ev,
            ))

        if old.value_range and new.value_range and old.value_range != new.value_range:
            narrowed = _range_narrowed(old.value_range, new.value_range)
            out.append(InterfaceChange(
                rule_id="DG1101", symbol=cmd, kind="parameter",
                change_type="range_changed", breaking=False,
                before=f"<{name}> range {old.value_range[0]}..{old.value_range[1]}",
                after=f"<{name}> range {new.value_range[0]}..{new.value_range[1]}",
                description=(
                    f"Parameter <{name}> range {'narrowed' if narrowed else 'changed'}. "
                    "DeviceGuard checks direct literal call sites and otherwise requires review."
                ),
                evidence=ev,
                metadata={
                    "parameter": name,
                    "parameter_index": (_parameter_order(b).index(name) if name in _parameter_order(b) else None),
                    "old_range": list(old.value_range),
                    "new_range": list(new.value_range),
                    "narrowed": narrowed,
                },
            ))

        if old.enum_values and new.enum_values and old.enum_values != new.enum_values:
            removed = sorted(old.enum_values - new.enum_values)
            added = sorted(new.enum_values - old.enum_values)
            parts = []
            if removed:
                parts.append("removed values: " + ", ".join(removed))
            if added:
                parts.append("added values: " + ", ".join(added))
            out.append(InterfaceChange(
                rule_id="DG1100", symbol=cmd, kind="parameter",
                change_type="enum_changed", breaking=False,
                before=f"<{name}> values {{{', '.join(sorted(old.enum_values))}}}",
                after=f"<{name}> values {{{', '.join(sorted(new.enum_values))}}}",
                description=f"Parameter <{name}> enum changed ({'; '.join(parts)}). DeviceGuard checks direct literal call sites and otherwise requires review.",
                evidence=ev,
                metadata={
                    "parameter": name,
                    "parameter_index": (_parameter_order(b).index(name) if name in _parameter_order(b) else None),
                    "old_enum": sorted(old.enum_values),
                    "new_enum": sorted(new.enum_values),
                    "removed_enum": removed,
                    "added_enum": added,
                },
            ))
    return out


def diff_specs(old_path: Path, new_path: Path) -> tuple[list[InterfaceChange], SpecVerification]:
    old = parse_spec(old_path)
    new = parse_spec(new_path)
    out: list[InterfaceChange] = []
    ev = _ev(old_path, new_path)

    for cmd in sorted(set(old.commands) | set(new.commands)):
        a = old.commands.get(cmd)
        b = new.commands.get(cmd)
        if a is not None and b is None:
            out.append(InterfaceChange(
                rule_id="DG1001", symbol=cmd, kind="command", change_type="command_removed", breaking=True,
                description="Old/new AT manuals prove that this command is no longer present in the new spec.", evidence=ev,
            ))
            continue
        if a is None and b is not None:
            out.append(InterfaceChange(
                rule_id="DG1021", symbol=cmd, kind="command", change_type="command_added", breaking=False,
                description="Old/new AT manuals prove that this command was added in the new spec.", evidence=ev,
            ))
            continue
        assert a is not None and b is not None

        parameter_changes = _parameter_diffs(cmd, a, b, ev)
        if a.syntaxes and b.syntaxes and a.syntaxes != b.syntaxes and not parameter_changes:
            out.append(InterfaceChange(
                rule_id="DG1004", symbol=cmd, kind="command", change_type="signature_changed", breaking=True,
                before=" | ".join(sorted(a.syntaxes)), after=" | ".join(sorted(b.syntaxes)),
                description="Old/new AT manuals prove that the command syntax changed.", evidence=ev,
            ))

        out.extend(parameter_changes)

        if a.responses and b.responses and a.responses != b.responses:
            symbol = _response_symbol(cmd, b.responses or a.responses)
            out.append(InterfaceChange(
                rule_id="DG1011", symbol=symbol, kind="response", change_type="response_changed", breaking=True,
                before=" | ".join(sorted(a.responses)), after=" | ".join(sorted(b.responses)),
                description=f"Old/new AT manuals prove that the response contract for {cmd} changed.", evidence=ev,
            ))

    verification = SpecVerification(
        old_spec=str(old_path), new_spec=str(new_path), old_commands=len(old.commands),
        new_commands=len(new.commands), verified_diffs=len(out),
    )
    return out, verification
