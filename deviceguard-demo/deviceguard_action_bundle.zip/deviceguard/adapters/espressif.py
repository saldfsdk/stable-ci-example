from __future__ import annotations

"""Espressif ESP-AT compatibility adapter.

v0.3 replaces the tiny handwritten ESP-AT fixture with a live parser for
Espressif's official NONOS-AT -> ESP-AT comparison table.  The parser stays
conservative: removals and explicit parameter incompatibilities can BLOCK;
looser wording such as "response is different" is surfaced as REVIEW.

The official page is cached locally.  If the network is unavailable and no
cache exists, a very small fallback keeps the prototype usable with lower
confidence.
"""

import os
import re
import urllib.error
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

from deviceguard.models import Evidence, InterfaceChange

DOC_URL = (
    "https://docs.espressif.com/projects/esp-at/en/"
    "release-v2.2.0.0_esp32/AT_Command_Set/AT_Command_Set_Comparison.html"
)
DISPLAY_URL = DOC_URL


class _ComparisonTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._in_table = False
        self._in_row = False
        self._in_cell = False
        self._cell_parts: list[str] = []
        self._row: list[str] = []
        self.rows: list[list[str]] = []

    def handle_starttag(self, tag: str, attrs):
        attrs_d = dict(attrs)
        if tag == "table" and not self._in_table:
            self._in_table = True
            return
        if not self._in_table:
            return
        if tag == "tr":
            self._in_row = True
            self._row = []
        elif tag in {"td", "th"} and self._in_row:
            self._in_cell = True
            self._cell_parts = []
        elif tag == "img" and self._in_cell:
            alt = attrs_d.get("alt")
            if alt:
                self._cell_parts.append(alt)
        elif tag == "br" and self._in_cell:
            self._cell_parts.append(" ")

    def handle_data(self, data: str):
        if self._in_cell:
            self._cell_parts.append(data)

    def handle_endtag(self, tag: str):
        if not self._in_table:
            return
        if tag in {"td", "th"} and self._in_cell:
            text = " ".join("".join(self._cell_parts).split())
            self._row.append(text)
            self._in_cell = False
            self._cell_parts = []
        elif tag == "tr" and self._in_row:
            if self._row:
                self.rows.append(self._row)
            self._row = []
            self._in_row = False
        elif tag == "table":
            self._in_table = False


def _cache_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return root / "DeviceGuard" / "cache"
    root = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    return root / "deviceguard"


def _cache_file() -> Path:
    return _cache_dir() / "espressif_at_command_comparison_v2_2.html"


def _fetch_official_html(timeout: float = 8.0) -> str:
    req = urllib.request.Request(
        DOC_URL,
        headers={"User-Agent": "deviceguard/0.0.3 (+https://github.com/)"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read()
    return raw.decode("utf-8", errors="replace")


def load_official_html(*, refresh: bool = False) -> tuple[str | None, str]:
    cache = _cache_file()
    if not refresh and cache.exists():
        try:
            return cache.read_text(encoding="utf-8"), "cache"
        except OSError:
            pass

    try:
        html = _fetch_official_html()
        cache.parent.mkdir(parents=True, exist_ok=True)
        try:
            cache.write_text(html, encoding="utf-8")
        except OSError:
            pass
        return html, "live"
    except (OSError, urllib.error.URLError, TimeoutError):
        if cache.exists():
            try:
                return cache.read_text(encoding="utf-8"), "cache"
            except OSError:
                pass
        return None, "unavailable"


def _supported(cell: str) -> bool | None:
    low = cell.lower()
    if "icon-red-cross" in low or "❌" in cell:
        # Some rows contain per-chip mixtures of yes/no.  Only call it outright
        # unsupported when no positive marker is present.
        if "icon-green-check" not in low and "icon-orange-check" not in low and "✅" not in cell:
            return False
    if "icon-green-check" in low or "icon-orange-check" in low or "✅" in cell:
        return True
    return None


def _extract_symbol(cell: str) -> str | None:
    m = re.search(r"\b(AT(?:\+[A-Z0-9_]+|E\d*|\b))", cell)
    if not m:
        return None
    return m.group(1).strip()


def _replacement(cell: str) -> str | None:
    m = re.search(r"Similar command:\s*(AT\+[A-Z0-9_]+)", cell, flags=re.I)
    return m.group(1) if m else None


def _ev(confidence: float = 1.0, *, fallback: bool = False) -> Evidence:
    return Evidence(
        source=DISPLAY_URL,
        source_type="manual_fixture" if fallback else "official_spec",
        confidence=confidence,
    )


def parse_comparison_html(html: str) -> list[InterfaceChange]:
    parser = _ComparisonTableParser()
    parser.feed(html)
    rows = parser.rows

    items: list[InterfaceChange] = []
    for row in rows:
        if len(row) < 4:
            continue
        command, function, nonos, esp = row[0], row[1], row[2], row[3]
        symbol = _extract_symbol(command)
        if not symbol or symbol == "AT":
            continue

        old_support = _supported(nonos)
        new_support = _supported(esp)

        if old_support is True and new_support is False:
            repl = _replacement(esp)
            items.append(InterfaceChange(
                rule_id="DG1001",
                symbol=symbol,
                change_type="command_removed",
                breaking=True,
                replacement=repl,
                description=(
                    f"{function or 'Command'} is supported by NONOS-AT but not by ESP-AT."
                ),
                evidence=_ev(),
            ))
            continue

        if old_support is False and new_support is True:
            items.append(InterfaceChange(
                rule_id="DG1021",
                symbol=symbol,
                change_type="command_added",
                breaking=False,
                description=f"{function or 'Command'} was added in ESP-AT.",
                evidence=_ev(),
            ))
            continue

        if old_support is True and new_support is True:
            low = esp.lower()
            if "parameters are different" in low:
                items.append(InterfaceChange(
                    rule_id="DG1004",
                    symbol=symbol,
                    change_type="signature_changed",
                    breaking=True,
                    before="NONOS-AT parameter contract",
                    after="ESP-AT parameter contract (different)",
                    description="Vendor comparison explicitly marks command parameters as different.",
                    evidence=_ev(),
                ))
            elif "response is different" in low:
                items.append(InterfaceChange(
                    rule_id="DG1200",
                    symbol=symbol,
                    kind="behavior",
                    change_type="behavior_changed",
                    breaking=False,
                    description="Vendor comparison explicitly marks the command response as different.",
                    evidence=_ev(),
                ))
            elif any(marker in low for marker in (
                "added more functionality",
                "more parameters supported",
                "added automatic connection",
                "added the parameter",
            )):
                items.append(InterfaceChange(
                    rule_id="DG1200",
                    symbol=symbol,
                    kind="behavior",
                    change_type="behavior_changed",
                    breaking=False,
                    description=f"ESP-AT changes command semantics/capabilities: {esp}",
                    evidence=_ev(),
                ))

    # The comparison page documents sleep-mode value semantics in a footnote.
    # This is deliberately REVIEW rather than BLOCK because the row itself does
    # not provide a precise source-level signature contract.
    if "AT+SLEEP in ESP-AT" in html and not any(x.symbol == "AT+SLEEP" for x in items):
        items.append(InterfaceChange(
            rule_id="DG1200",
            symbol="AT+SLEEP",
            kind="behavior",
            change_type="behavior_changed",
            breaking=False,
            description="Sleep-mode value semantics differ between legacy NONOS-AT and ESP-AT.",
            evidence=_ev(),
        ))

    # Deduplicate symbols/change types while preserving order.
    out: list[InterfaceChange] = []
    seen: set[tuple[str, str, str]] = set()
    for item in items:
        key = (item.symbol, item.kind, item.change_type)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _seed_changes() -> list[InterfaceChange]:
    ev = _ev(0.92, fallback=True)
    return [
        InterfaceChange(
            rule_id="DG1001",
            symbol="AT+WAKEUPGPIO",
            change_type="command_removed",
            breaking=True,
            replacement="AT+SLEEPWKCFG",
            description="Legacy wake-up GPIO command is not supported in ESP-AT; replacement exists.",
            evidence=ev,
        ),
        InterfaceChange(
            rule_id="DG1200",
            symbol="AT+SLEEP",
            kind="behavior",
            change_type="behavior_changed",
            breaking=False,
            description="Sleep command behavior/parameter semantics differ across legacy NONOS-AT and ESP-AT.",
            evidence=ev,
        ),
    ]


def changes(from_version: str, to_version: str, *, refresh: bool = False) -> list[InterfaceChange]:
    if from_version.lower() not in {"nonos", "nonos-at", "legacy"}:
        raise ValueError(
            "Espressif live adapter v0.3 currently supports the NONOS-AT -> ESP-AT migration path only."
        )

    html, _mode = load_official_html(refresh=refresh)
    if html:
        parsed = parse_comparison_html(html)
        if parsed:
            return parsed
    return _seed_changes()
