from __future__ import annotations

"""Generic bring-your-own vendor document adapter.

v0.5 adds a version-aware path for cumulative Quectel-style release notes.
Many modem release-note PDFs contain years of historical rows, each tagged with
"Since" firmware version. Treating every row as part of the requested upgrade
creates false positives. DeviceGuard now detects the document's preamble,
reconstructs split version cells, and scopes rows to the requested target
version when that evidence is available.

The generic conservative parser remains the fallback for arbitrary vendor
documents. Uploaded documents are evidence, not ground truth: explicit
removals/signature changes can block a release, while ambiguous behavioural
wording becomes REVIEW rather than BLOCK.
"""

import re
from dataclasses import dataclass
from pathlib import Path

from deviceguard.models import DocumentScope, Evidence, InterfaceChange

_CMD = r"AT(?:\+|#|%)[A-Z0-9_]+"
_FULL_VERSION_RE = re.compile(r"\b(?:BG\w+)?R\d{2}A\d{2}_\d{2}\.\d{3}\.\d{2}\.\d{3}\b", re.I)
_SINCE_VERSION_RE = re.compile(r"\bR\d{2}A\d{2}_\d{2}\.\d{3}\.\d{2}\.\d{3}\b", re.I)
_SPLIT_VERSION_HEAD_RE = re.compile(r"^R\d{2}A\d{2}_\d{2}\.$", re.I)
_SPLIT_VERSION_TAIL_RE = re.compile(r"^\d{3}\.\d{2}\.\d{3}$")


@dataclass(frozen=True)
class DocumentVersions:
    from_version: str | None = None
    to_version: str | None = None


def _read_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise ValueError(
            "PDF support requires pypdf. Install it with: python -m pip install pypdf"
        ) from exc

    try:
        reader = PdfReader(str(path))
        parts: list[str] = []
        for page in reader.pages:
            text = page.extract_text() or ""
            if text:
                parts.append(text)
        return "\n".join(parts)
    except Exception as exc:
        raise ValueError(f"Could not read vendor PDF: {path}: {exc}") from exc


def load_document(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _read_pdf(path)
    if suffix in {".txt", ".md", ".rst", ".log", ".csv"}:
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            raise ValueError(f"Could not read vendor document: {path}: {exc}") from exc
    raise ValueError(
        f"Unsupported vendor document type: {suffix or '(no extension)'}. "
        "Use PDF, TXT, MD, RST, LOG, or CSV."
    )


def _evidence(path: Path, confidence: float) -> Evidence:
    return Evidence(
        source=str(path),
        source_type="vendor_document",
        confidence=confidence,
    )


def _clean_lines(text: str) -> list[str]:
    raw = [re.sub(r"\s+", " ", ln).strip() for ln in text.splitlines()]
    raw = [ln for ln in raw if ln]

    # pypdf frequently splits Quectel's Since cell:
    #   R02A04_01.
    #   003.01.003
    # Join it before row reconstruction.
    joined: list[str] = []
    i = 0
    while i < len(raw):
        if (
            i + 1 < len(raw)
            and _SPLIT_VERSION_HEAD_RE.match(raw[i])
            and _SPLIT_VERSION_TAIL_RE.match(raw[i + 1])
        ):
            joined.append(raw[i] + raw[i + 1])
            i += 2
            continue
        joined.append(raw[i])
        i += 1
    return joined


def _context_lines(text: str) -> list[str]:
    """Build conservative local windows for generic PDF rows split across lines.

    Combined windows are emitted only when they contain at most one distinct AT
    command. This prevents an adjacent table row (for example a removed command
    followed by an added command) from inheriting the previous row's verb.
    """
    raw = _clean_lines(text)
    windows: list[str] = []
    for i, line in enumerate(raw):
        windows.append(line)
        for width in (2, 3):
            if i + width > len(raw):
                continue
            candidate = " ".join(raw[i:i + width])
            commands = {c.upper() for c in re.findall(_CMD, candidate, flags=re.I)}
            if len(commands) <= 1:
                windows.append(candidate)
    return windows


def _commands(s: str) -> list[str]:
    """Extract commands, including Quectel slash shorthand.

    Example: ``AT+QFCRC/AT+QFCPY`` is straightforward, while some extracted
    tables render a shorthand like ``AT+QFCRC/QFCPY``. The latter is expanded
    to AT+QFCRC and AT+QFCPY.
    """
    found = re.findall(_CMD, s, flags=re.I)

    # Expand AT+FOO/BAR to AT+FOO and AT+BAR when BAR looks like an AT suffix.
    for m in re.finditer(r"\bAT(?P<prefix>[+#%])(?P<first>[A-Z0-9_]+)(?P<tail>(?:/[A-Z][A-Z0-9_]+)+)", s, flags=re.I):
        prefix = m.group("prefix")
        for suffix in m.group("tail").split("/"):
            if suffix:
                found.append(f"AT{prefix}{suffix}")

    out: list[str] = []
    seen: set[str] = set()
    for cmd in found:
        cmd = cmd.upper()
        if cmd not in seen:
            seen.add(cmd)
            out.append(cmd)
    return out


def _make(
    *,
    path: Path,
    rule_id: str,
    symbol: str,
    change_type: str,
    breaking: bool,
    description: str,
    kind: str = "command",
    before: str | None = None,
    after: str | None = None,
    replacement: str | None = None,
    confidence: float = 0.94,
) -> InterfaceChange:
    return InterfaceChange(
        rule_id=rule_id,
        symbol=symbol,
        kind=kind,
        change_type=change_type,
        breaking=breaking,
        before=before,
        after=after,
        replacement=replacement,
        description=description,
        evidence=_evidence(path, confidence),
    )


def _classify_context(ctx: str, path: Path) -> list[InterfaceChange]:
    """Classify one self-contained row/window into conservative IR."""
    items: list[InterfaceChange] = []
    low = ctx.lower()
    cmds = _commands(ctx)
    if not cmds:
        return items

    rename = re.search(
        rf"(?P<old>{_CMD}).{{0,90}}?(?:renamed|rename|replaced|replace).{{0,90}}?(?:to|with|by)\s+(?P<new>{_CMD})",
        ctx,
        flags=re.I,
    )
    if rename:
        old, new = rename.group("old").upper(), rename.group("new").upper()
        return [_make(
            path=path, rule_id="DG1002", symbol=old,
            change_type="command_renamed", breaking=True,
            replacement=new,
            description=f"Vendor document says the command was renamed/replaced by {new}.",
            confidence=0.94,
        )]

    removal_markers = (
        "removed", "deleted", "no longer supported", "not supported anymore",
        "unsupported", "discontinued",
    )
    if any(marker in low for marker in removal_markers):
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1001", symbol=cmd,
                change_type="command_removed", breaking=True,
                description="Vendor document explicitly marks this command as removed/unsupported.",
                confidence=0.94,
            ))
        return items

    signature_markers = (
        "syntax changed", "command syntax changed", "parameters changed",
        "parameter changed", "parameter order changed", "parameter order",
        "changed parameters", "different parameters", "signature changed",
    )
    added_parameter = (
        ("added parameter" in low or "added the parameter" in low or "new parameter" in low)
        and not low.startswith("added command")
    )
    if any(marker in low for marker in signature_markers):
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1004", symbol=cmd,
                change_type="signature_changed", breaking=True,
                description="Vendor document explicitly says the command syntax/parameter contract changed.",
                confidence=0.94,
            ))
        return items
    if added_parameter:
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1200", symbol=cmd,
                kind="behavior", change_type="behavior_changed", breaking=False,
                description="Vendor document adds a parameter, but does not provide enough structure to prove source incompatibility.",
                confidence=0.92,
            ))
        return items

    response_markers = (
        "response changed", "response is changed", "response format changed",
        "output changed", "returns instead", "now returns", "now output",
        "values instead of", "fields instead of", "returned incorrect result",
        "incorrect result", "incorrect error code", "urc results were not returned",
        "urc was not reported", "urc report",
    )
    if any(marker in low for marker in response_markers):
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1200", symbol=cmd,
                kind="behavior", change_type="behavior_changed", breaking=False,
                description="Vendor document indicates a response/output behavior change.",
                confidence=0.93,
            ))
        return items

    # Bug fixes/optimizations can change observable behavior. Quectel cumulative
    # notes contain many of these and they are useful REVIEW findings when the
    # host source actually uses the named command.
    if any(marker in low for marker in ("fixed", "fixes", "resolved", "issue", "bug", "optimized")):
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1200", symbol=cmd,
                kind="behavior", change_type="behavior_changed", breaking=False,
                description="Vendor document reports a fix/change involving this command; review host assumptions.",
                confidence=0.88,
            ))
        return items

    add_command_patterns = (
        r"\badded\s+(?:support\s+for\s+)?(?:the\s+)?(?:new\s+)?(?:at\s+)?command",
        r"\bnew\s+(?:at\s+)?command",
        r"\badded\s+support\s+(?:for\s+)?AT[+#%]",
        r"\badded\s+AT[+#%]",
        r"\bsupported\s+(?:the\s+)?(?:new\s+)?(?:at\s+)?command",
    )
    if any(re.search(pat, ctx, flags=re.I) for pat in add_command_patterns):
        for cmd in cmds:
            items.append(_make(
                path=path, rule_id="DG1021", symbol=cmd,
                change_type="command_added", breaking=False,
                description="Vendor document adds/supports this command.",
                confidence=0.94,
            ))
        return items

    return items


def _dedupe(items: list[InterfaceChange]) -> list[InterfaceChange]:
    priority = {
        "command_removed": 5,
        "command_renamed": 5,
        "signature_changed": 4,
        "response_changed": 3,
        "behavior_changed": 2,
        "command_added": 1,
    }
    best: dict[str, InterfaceChange] = {}
    order: list[str] = []
    for item in items:
        if item.symbol not in best:
            best[item.symbol] = item
            order.append(item.symbol)
            continue
        old = best[item.symbol]
        if priority.get(item.change_type, 0) > priority.get(old.change_type, 0):
            best[item.symbol] = item
    return [best[s] for s in order]


def parse_document_text(text: str, path: Path) -> list[InterfaceChange]:
    items: list[InterfaceChange] = []
    for ctx in _context_lines(text):
        items.extend(_classify_context(ctx, path))
    return _dedupe(items)


def detect_document_versions(text: str) -> DocumentVersions:
    """Detect target/base versions from common Quectel preamble wording."""
    compact = re.sub(r"\s+", " ", text)
    # Keep this intentionally specific: false version claims are worse than no
    # version detection. Target appears first, baseline after "compared to".
    m = re.search(
        r"Release Notes for .*? firmware version:\s*(?P<to>[A-Z0-9_.]+).*?"
        r"compared to .*? firmware version\s*(?P<from>[A-Z0-9_.]+)",
        compact,
        flags=re.I,
    )
    if not m:
        return DocumentVersions()
    return DocumentVersions(
        from_version=m.group("from").rstrip(". ,;"),
        to_version=m.group("to").rstrip(". ,;"),
    )


def _version_aliases(version: str | None) -> set[str]:
    if not version:
        return set()
    v = version.upper().strip().rstrip(". ,;")
    aliases = {v}
    # BG95M3LAR02A04_01.003.01.003 -> R02A04_01.003.01.003 and 01.003.01.003
    m = re.search(r"(R\d{2}A\d{2}_\d{2}\.\d{3}\.\d{2}\.\d{3})$", v)
    if m:
        short = m.group(1)
        aliases.add(short)
        aliases.add(short.split("_", 1)[1])
    m2 = re.search(r"(\d{2}\.\d{3}\.\d{2}\.\d{3})$", v)
    if m2:
        aliases.add(m2.group(1))
    return aliases


def _version_matches(candidate: str, requested: str | None) -> bool:
    cand = candidate.upper().strip().rstrip(". ,;")
    aliases = _version_aliases(requested)
    if not aliases:
        return False
    return any(cand == a or cand.endswith(a) or a.endswith(cand) for a in aliases)




def _is_specific_version(version: str) -> bool:
    v = version.upper()
    return bool(
        re.search(r"R\d{2}A\d{2}_\d{2}\.\d{3}\.\d{2}\.\d{3}", v)
        or re.search(r"\d{2}\.\d{3}\.\d{2}\.\d{3}", v)
    )


def _validate_detected_pair(
    detected: DocumentVersions, requested_from: str, requested_to: str
) -> None:
    """Reject a confidently wrong full-version/document pairing.

    Coarse labels such as OLD..NEW or A04..A05 are allowed because they may be
    intentional user aliases. Full firmware versions must agree with the PDF.
    """
    if detected.from_version and _is_specific_version(requested_from):
        if not _version_matches(detected.from_version, requested_from):
            raise ValueError(
                "Vendor document version mismatch: requested from-version "
                f"{requested_from}, but the document says {detected.from_version}."
            )
    if detected.to_version and _is_specific_version(requested_to):
        if not _version_matches(detected.to_version, requested_to):
            raise ValueError(
                "Vendor document version mismatch: requested to-version "
                f"{requested_to}, but the document says {detected.to_version}."
            )

def _looks_like_quectel_release_note(text: str) -> bool:
    head = text[:12000].lower()
    return (
        "quectel" in head
        and "release notes" in head
        and "brief description" in head
        and (" since" in head or "since\n" in head)
    )


def _quectel_rows(text: str) -> list[tuple[str, str]]:
    """Reconstruct cumulative Quectel table rows as (description, since_version).

    pypdf preserves the logical reading order reasonably well, but wraps the
    description and version cells across lines. A row terminates when a Since
    version token is encountered. Header/footer lines are tolerated because
    rows without AT commands are ignored later.
    """
    lines = _clean_lines(text)
    rows: list[tuple[str, str]] = []
    buf: list[str] = []
    for line in lines:
        m = _SINCE_VERSION_RE.search(line)
        if m:
            before = line[:m.start()].strip()
            if before:
                buf.append(before)
            desc = " ".join(buf).strip()
            if desc:
                rows.append((desc, m.group(0).upper()))
            buf = []
            after = line[m.end():].strip()
            if after:
                buf.append(after)
        else:
            # Avoid letting page furniture poison the next row. These strings
            # commonly appear in Quectel PDFs but carry no row semantics.
            low = line.lower()
            if (
                "confidential / released" in low
                or low == "quectel confidential"
                or re.match(r"^bg\w+_release_notes\b", low)
                or low.startswith("lpwa module series")
            ):
                continue
            buf.append(line)
    return rows


def parse_quectel_release_note(
    text: str,
    path: Path,
    from_version: str,
    to_version: str,
) -> list[InterfaceChange] | None:
    """Parse version-scoped rows from Quectel cumulative release notes.

    Returns None when the document is not confidently recognized, allowing the
    generic parser to handle arbitrary documents.
    """
    if not _looks_like_quectel_release_note(text):
        return None

    detected = detect_document_versions(text)

    # Prefer the caller's target when it can be mapped to the document. If the
    # caller used a coarse label (e.g. A04..A05) that does not map to the Since
    # cells, only activate version scoping when the document preamble itself
    # provides an unambiguous target.
    target_candidates = _version_aliases(to_version)
    if detected.to_version:
        target_candidates |= _version_aliases(detected.to_version)

    rows = _quectel_rows(text)
    if not rows:
        return []

    # Determine whether at least one row maps to target. If not, do not invent
    # a mapping; fall back to the generic parser.
    scoped_rows = [
        (desc, since)
        for desc, since in rows
        if any(_version_matches(since, t) for t in target_candidates)
    ]
    if not scoped_rows:
        return None

    items: list[InterfaceChange] = []
    for desc, since in scoped_rows:
        # Include Since in the context only as evidence text; classification is
        # driven by the row description.
        row_items = _classify_context(desc, path)
        for item in row_items:
            # Preserve conservative vendor-document confidence, but make the
            # description explain why this row belongs to this upgrade.
            item.description = f"{item.description} Since {since}."
        items.extend(row_items)

    return _dedupe(items)


def analyze_document(
    path: Path, from_version: str, to_version: str
) -> tuple[list[InterfaceChange], DocumentScope]:
    text = load_document(path)
    detected = detect_document_versions(text)
    if _looks_like_quectel_release_note(text):
        _validate_detected_pair(detected, from_version, to_version)

    scoped = parse_quectel_release_note(text, path, from_version, to_version)
    if scoped is not None:
        rows = _quectel_rows(text)
        target = detected.to_version or to_version
        scoped_row_count = sum(1 for _, since in rows if _version_matches(since, target))
        parsed = scoped
        scope = DocumentScope(
            mode="quectel_version_scoped",
            detected_from=detected.from_version,
            detected_to=detected.to_version,
            source_rows=len(rows),
            scoped_rows=scoped_row_count,
        )
    else:
        parsed = parse_document_text(text, path)
        scope = DocumentScope(
            mode="generic",
            detected_from=detected.from_version,
            detected_to=detected.to_version,
        )

    if not parsed:
        raise ValueError(
            "No explicit AT-interface changes could be extracted from the vendor document. "
            "DeviceGuard intentionally refuses to invent changes from ambiguous prose."
        )
    return parsed, scope


def changes(path: Path, from_version: str, to_version: str) -> list[InterfaceChange]:
    parsed, _scope = analyze_document(path, from_version, to_version)
    return parsed
