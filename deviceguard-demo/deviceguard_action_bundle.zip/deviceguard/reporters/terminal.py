from __future__ import annotations
from rich.console import Console
from rich.table import Table
from deviceguard.models import Report

console = Console()


def render(report: Report) -> None:
    console.print("[bold]DEVICEGUARD[/bold]")
    console.print(f"{report.dependency}  {report.from_version} → {report.to_version}\n")
    if report.document_scope is not None and report.document_scope.mode == "quectel_version_scoped":
        scope = report.document_scope
        if scope.detected_from and scope.detected_to:
            console.print(f"vendor document: {scope.detected_from} → {scope.detected_to}")
        if scope.source_rows is not None and scope.scoped_rows is not None:
            console.print(f"version scope: {scope.scoped_rows} of {scope.source_rows} cumulative rows")
        console.print()
    if report.spec_verification is not None:
        sv = report.spec_verification
        console.print(f"spec verification: {sv.old_commands} old commands → {sv.new_commands} new commands; {sv.verified_diffs} verified diffs")
        console.print()
    console.print(f"{report.upstream_changes} upstream changes")
    console.print(f"{report.relevant_changes} affect this repository\n")

    shown = [f for f in report.findings if f.verdict != "not_used"]
    for f in shown:
        label = {
            "proven_breaking": "[bold red]BLOCK[/bold red]",
            "likely_breaking": "[bold yellow]LIKELY BREAKING[/bold yellow]",
            "review_required": "[bold yellow]REVIEW[/bold yellow]",
            "compatible": "[green]PASS[/green]",
        }.get(f.verdict, f.verdict.upper())
        console.print(f"{label}  [bold]{f.change.symbol}[/bold]  ({f.change.rule_id})")
        if f.change.description:
            console.print(f"  {f.change.description}")
        if f.change.before:
            console.print(f"  old: {f.change.before}")
        if f.change.after:
            console.print(f"  new: {f.change.after}")
        if f.change.replacement:
            console.print(f"  replacement: {f.change.replacement}")
        for u in f.usages:
            console.print(f"  {u.file}:{u.line}:{u.column}  [{u.kind}] {u.excerpt}")
            wrapper = u.metadata.get("wrapper") if u.metadata else None
            if isinstance(wrapper, dict):
                console.print(
                    f"    via: static wrapper {wrapper.get('function')}() "
                    f"→ {wrapper.get('body_file')}:{wrapper.get('body_line')}"
                )
            args = u.metadata.get("command_args") if u.metadata else None
            param_index = f.change.metadata.get("parameter_index") if f.change.metadata else None
            param_name = f.change.metadata.get("parameter") if f.change.metadata else None
            if isinstance(args, list) and isinstance(param_index, int) and param_index < len(args):
                item = args[param_index]
                if isinstance(item, dict) and item.get("value") is not None:
                    label = f"<{param_name}>" if param_name else f"arg[{param_index}]"
                    console.print(f"    resolved: {label}={item.get('value')} ({item.get('source', 'static')})")
        console.print(f"  confidence: {f.confidence:.0%}\n")

    if report.release_blocked:
        console.print("[bold red]RELEASE BLOCKED[/bold red]")
    else:
        console.print("[bold green]PASS[/bold green]")
