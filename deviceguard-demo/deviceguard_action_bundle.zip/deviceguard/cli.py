from __future__ import annotations
import json
from pathlib import Path
import typer
from deviceguard.core import run_check
from deviceguard.reporters import render

app = typer.Typer(add_completion=False, help="Map vendor firmware interface changes to affected embedded source code.")

@app.callback()
def main():
    """DeviceGuard prototype CLI."""
    pass


def _parse_dep(dep: str):
    # vendor/product@from..to
    try:
        name, versions = dep.split("@", 1)
        vendor, product = name.split("/", 1)
        from_v, to_v = versions.split("..", 1)
        return vendor, product, from_v, to_v
    except ValueError as e:
        raise typer.BadParameter("Use vendor/product@from..to") from e

@app.command()
def check(
    dependency: str = typer.Argument(..., help="Example: nordic/serial-modem@3.1..4.0"),
    repo: Path = typer.Argument(Path("."), exists=True, file_okay=False, dir_okay=True),
    format: str = typer.Option("terminal", "--format", help="terminal or json"),
    refresh_vendor_data: bool = typer.Option(
        False,
        "--refresh-vendor-data",
        help="Refresh public vendor migration documentation before analysis.",
    ),
    old_spec: Path | None = typer.Option(None, "--old-spec", exists=True, file_okay=True, dir_okay=False, help="Old AT command manual PDF/TXT/MD/RST."),
    new_spec: Path | None = typer.Option(None, "--new-spec", exists=True, file_okay=True, dir_okay=False, help="New AT command manual PDF/TXT/MD/RST."),
    vendor_doc: Path | None = typer.Option(
        None,
        "--vendor-doc",
        exists=True,
        file_okay=True,
        dir_okay=False,
        help="Use a vendor-supplied PDF/TXT/MD/RST release note instead of a built-in adapter.",
    ),
):
    vendor, product, from_v, to_v = _parse_dep(dependency)
    try:
        report = run_check(
            vendor,
            product,
            from_v,
            to_v,
            repo,
            refresh_vendor_data=refresh_vendor_data,
            vendor_doc=vendor_doc,
            old_spec=old_spec,
            new_spec=new_spec,
        )
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(3)
    if format == "json":
        typer.echo(json.dumps(report.model_dump(), indent=2, ensure_ascii=False))
    else:
        render(report)
    if report.release_blocked:
        raise typer.Exit(1)

if __name__ == "__main__":
    app()
