from __future__ import annotations
import re
from deviceguard.models import Finding, InterfaceChange, Usage


def _combine(evidence_conf: float, usage_conf: float) -> float:
    return round(min(evidence_conf, usage_conf), 3)


def _static_argument(usage: Usage, symbol: str, index: int | None) -> tuple[str | None, bool, str | None]:
    """Return (value, present, provenance) for a statically inspectable AT argument."""
    if index is None:
        return None, False, None
    command_args = usage.metadata.get("command_args") if usage.metadata else None
    if isinstance(command_args, list):
        if index >= len(command_args):
            return None, False, None
        item = command_args[index]
        if isinstance(item, dict):
            value = item.get("value")
            return (str(value) if value is not None else None, bool(item.get("present", True)), item.get("source"))

    # Backward-compatible literal path.
    if usage.kind not in {"literal", "macro"}:
        return None, False, None
    pos = usage.excerpt.find(symbol)
    if pos < 0:
        return None, False, None
    tail = usage.excerpt[pos + len(symbol):]
    if not tail.startswith("="):
        return None, False, None
    tail = tail[1:].split('"', 1)[0]
    args = [x.strip() for x in tail.split(",")]
    if index >= len(args):
        return None, False, None
    token = args[index].strip().strip("'\"")
    if re.fullmatch(r"[-+]?\d+(?:\.\d+)?", token):
        return token, True, "literal"
    return None, True, None


def _numeric(v: str) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _semantic_value_verdict(change: InterfaceChange, hits: list[Usage]) -> str:
    index = change.metadata.get("parameter_index")
    exact_values: list[str] = []
    unknown = False
    for hit in hits:
        value, present, _ = _static_argument(hit, change.symbol, index if isinstance(index, int) else None)
        if not present or value is None:
            unknown = True
        else:
            exact_values.append(value)

    if change.change_type == "enum_changed":
        allowed = {str(x) for x in change.metadata.get("new_enum", [])}
        if exact_values and any(v not in allowed for v in exact_values):
            return "proven_breaking"
        if exact_values and not unknown and all(v in allowed for v in exact_values):
            return "compatible"
        return "review_required"

    if change.change_type == "range_changed":
        nr = change.metadata.get("new_range")
        if isinstance(nr, list) and len(nr) == 2:
            lo, hi = _numeric(str(nr[0])), _numeric(str(nr[1]))
            nums = [_numeric(v) for v in exact_values]
            if lo is not None and hi is not None:
                if any(v is not None and not (lo <= v <= hi) for v in nums):
                    return "proven_breaking"
                if nums and not unknown and all(v is not None and lo <= v <= hi for v in nums):
                    return "compatible"
        return "review_required"

    return "review_required"


def _required_parameter_verdict(change: InterfaceChange, hits: list[Usage]) -> str | None:
    """Prove whether each static call site already supplies the now-required parameter."""
    if change.change_type not in {"parameter_optional_to_required", "required_parameter_added"}:
        return None
    index = change.metadata.get("parameter_index")
    if not isinstance(index, int):
        return None
    states = []
    for hit in hits:
        _, present, _ = _static_argument(hit, change.symbol, index)
        # If metadata is unavailable on a dynamic/text hit, we cannot prove safety.
        has_contract = isinstance(hit.metadata.get("command_args") if hit.metadata else None, list)
        states.append((present, has_contract))
    if any(has_contract and not present for present, has_contract in states):
        return "proven_breaking"
    if states and all(has_contract and present for present, has_contract in states):
        return "compatible"
    return None


def evaluate(changes: list[InterfaceChange], usages: dict[str, list]) -> list[Finding]:
    findings: list[Finding] = []
    for change in changes:
        hits = usages.get(change.symbol, [])
        if not hits:
            findings.append(Finding(change=change, usages=[], verdict="not_used", confidence=change.evidence.confidence))
            continue

        usage_conf = max(u.confidence for u in hits)
        conf = _combine(change.evidence.confidence, usage_conf)

        required_verdict = _required_parameter_verdict(change, hits)
        if required_verdict is not None:
            verdict = required_verdict
        elif change.change_type in {"enum_changed", "range_changed"}:
            verdict = _semantic_value_verdict(change, hits)
        elif change.kind == "behavior" or change.change_type == "behavior_changed":
            verdict = "review_required"
        elif change.breaking and conf >= 0.95:
            verdict = "proven_breaking"
        elif change.breaking:
            verdict = "likely_breaking"
        else:
            verdict = "compatible"
        findings.append(Finding(change=change, usages=hits, verdict=verdict, confidence=conf))
    return findings
